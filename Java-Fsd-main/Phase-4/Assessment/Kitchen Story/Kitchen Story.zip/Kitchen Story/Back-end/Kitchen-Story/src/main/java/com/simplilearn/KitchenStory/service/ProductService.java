package com.simplilearn.KitchenStory.service;

import com.simplilearn.KitchenStory.entity.Product;

public interface ProductService {

    public void save(Product theProduct);


}
