import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-outlet',
  templateUrl: './product-outlet.component.html',
  styleUrls: ['./product-outlet.component.css']
})
export class ProductOutletComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
