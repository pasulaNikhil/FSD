package com.medicare.helper;

public class UserNotFoundException extends Exception {

    public UserNotFoundException(String message){
        super(message);
    }
    
}
