import { Engineer } from './engineer';

describe('Engineer', () => {
  it('should create an instance', () => {
    expect(new Engineer()).toBeTruthy();
  });
});
