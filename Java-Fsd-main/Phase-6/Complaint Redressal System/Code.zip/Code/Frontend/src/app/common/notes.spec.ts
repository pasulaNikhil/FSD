import { Notes } from './notes';

describe('Notes', () => {
  it('should create an instance', () => {
    expect(new Notes()).toBeTruthy();
  });
});
