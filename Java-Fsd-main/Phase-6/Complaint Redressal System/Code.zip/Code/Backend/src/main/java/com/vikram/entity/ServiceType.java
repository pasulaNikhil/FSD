package com.vikram.entity;

public enum ServiceType {

	LANDLINE, MOBILE, FIBER_OPTIC;
}
