package com.vikram.entity;

public enum Status {

	RAISED, ASSIGNED, WIP, RESOLVED, ESCALATED;
}
